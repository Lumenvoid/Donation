const amount = document.querySelector("#amount");
const button = document.querySelector("#donate");
const statusEl = document.querySelector("#status");

button.addEventListener("click", async () => {
  button.disabled = true;
  statusEl.textContent = "Creating PayPal payment...";

  try {
    const create = await fetch("/api/donate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount: amount.value })
    });

    const created = await create.json();

    if (!create.ok) throw new Error(created.error || "Could not create payment.");

    /*
      This starter intentionally stops here.
      To show the PayPal Buttons SDK, add the official PayPal JS SDK
      with the client ID and use createOrder/capture against these
      server endpoints. Never expose PAYPAL_CLIENT_SECRET.
    */

    statusEl.textContent =
      `PayPal order created: ${created.orderId}. Connect the PayPal JS SDK to continue.`;
  } catch (err) {
    statusEl.textContent = err.message;
  } finally {
    button.disabled = false;
  }
});
