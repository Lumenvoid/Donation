require("dotenv").config();

const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const crypto = require("crypto");
const path = require("path");

const db = require("./db");
const { hashPassword, verifyPassword } = require("./auth");
const { PAYPAL_API, getAccessToken } = require("./paypal");

const app = express();
const PORT = Number(process.env.PORT || 3000);

if (!process.env.SESSION_SECRET) {
  throw new Error("SESSION_SECRET is required");
}

app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "20kb" }));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 1000 * 60 * 60
  }
}));

app.use(express.static(path.join(__dirname, "public")));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false
});

const donationLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false
});

function requireAdmin(req, res, next) {
  if (!req.session.adminId) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

function cleanAmount(value) {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return null;
  if (amount < 1 || amount > 10000) return null;
  return Math.round(amount * 100);
}

function getAvailableCents() {
  const completed = db.prepare(`
    SELECT COALESCE(SUM(amount_cents), 0) AS total
    FROM donations
    WHERE status = 'COMPLETED'
  `).get().total;

  const collected = db.prepare(`
    SELECT COALESCE(SUM(total_cents), 0) AS total
    FROM collections
    WHERE status IN ('PENDING', 'PROCESSING', 'COMPLETED')
  `).get().total;

  return Math.max(0, completed - collected);
}

app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"));
});

app.post("/api/admin/login", loginLimiter, (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");

  const admin = db.prepare(`
    SELECT id, password_hash
    FROM admins
    WHERE username = ?
  `).get(username);

  if (!admin || !verifyPassword(password, admin.password_hash)) {
    return res.status(401).json({ error: "Invalid credentials" });
  }

  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: "Login failed" });
    req.session.adminId = admin.id;
    res.json({ success: true });
  });
});

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
});

app.get("/api/admin/stats", requireAdmin, (req, res) => {
  const total = db.prepare(`
    SELECT COALESCE(SUM(amount_cents), 0) AS total
    FROM donations
    WHERE status = 'COMPLETED'
  `).get().total;

  const available = getAvailableCents();

  res.json({
    total: (total / 100).toFixed(2),
    available: (available / 100).toFixed(2)
  });
});

app.post("/api/donate", donationLimiter, async (req, res) => {
  try {
    const cents = cleanAmount(req.body.amount);

    if (cents === null) {
      return res.status(400).json({
        error: "Amount must be between €1 and €10,000."
      });
    }

    const token = await getAccessToken();

    const response = await fetch(`${PAYPAL_API}/v2/checkout/orders`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [{
          amount: {
            currency_code: "EUR",
            value: (cents / 100).toFixed(2)
          }
        }]
      })
    });

    const order = await response.json();

    if (!response.ok || !order.id) {
      console.error("PayPal create order:", order);
      return res.status(502).json({ error: "Could not create PayPal order." });
    }

    db.prepare(`
      INSERT INTO donations
        (paypal_order_id, amount_cents, currency, status)
      VALUES (?, ?, ?, ?)
    `).run(order.id, cents, "EUR", "CREATED");

    res.json({ orderId: order.id });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Payment error." });
  }
});

app.post("/api/donate/capture", donationLimiter, async (req, res) => {
  try {
    const orderId = String(req.body.orderId || "");

    if (!/^[A-Z0-9-]{10,100}$/i.test(orderId)) {
      return res.status(400).json({ error: "Invalid order ID." });
    }

    const existing = db.prepare(`
      SELECT status FROM donations WHERE paypal_order_id = ?
    `).get(orderId);

    if (!existing) {
      return res.status(404).json({ error: "Unknown order." });
    }

    if (existing.status === "COMPLETED") {
      return res.json({ success: true });
    }

    const token = await getAccessToken();

    const response = await fetch(
      `${PAYPAL_API}/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      }
    );

    const order = await response.json();

    if (!response.ok) {
      console.error("PayPal capture:", order);
      return res.status(400).json({ error: "Capture failed." });
    }

    const capture =
      order.purchase_units?.[0]?.payments?.captures?.[0];

    if (order.status !== "COMPLETED" ||
        !capture ||
        capture.status !== "COMPLETED") {
      return res.status(400).json({ error: "Payment not completed." });
    }

    // Verify the captured amount against the amount stored when the order was created.
    const stored = db.prepare(`
      SELECT amount_cents, currency
      FROM donations
      WHERE paypal_order_id = ?
    `).get(orderId);

    const paypalValue = capture.amount?.value;
    const paypalCurrency = capture.amount?.currency_code;

    if (
      paypalCurrency !== stored.currency ||
      Math.round(Number(paypalValue) * 100) !== stored.amount_cents
    ) {
      return res.status(400).json({
        error: "Payment amount verification failed."
      });
    }

    db.prepare(`
      UPDATE donations
      SET status = 'COMPLETED',
          paypal_capture_id = ?
      WHERE paypal_order_id = ?
    `).run(capture.id, orderId);

    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Payment verification failed." });
  }
});

/*
  IMPORTANT:
  The /api/admin/collect endpoint below intentionally creates a
  collection record and calculates 40/60 amounts, but does NOT pretend
  to complete PayPal payouts. Production payout implementation must use
  PayPal's supported Payouts / partner flow for the accounts involved,
  plus webhook/status handling and idempotency.

  This prevents the starter from falsely marking money as paid out.
*/
app.post("/api/admin/collect", requireAdmin, (req, res) => {
  const available = getAvailableCents();

  if (available <= 0) {
    return res.status(400).json({ error: "Nothing available to collect." });
  }

  const amount40 = Math.floor(available * 40 / 100);
  const amount60 = available - amount40;

  const transaction = db.transaction(() => {
    const result = db.prepare(`
      INSERT INTO collections
        (total_cents, amount_40_cents, amount_60_cents, status)
      VALUES (?, ?, ?, 'PENDING')
    `).run(available, amount40, amount60);

    return result.lastInsertRowid;
  });

  const id = transaction();

  res.json({
    success: true,
    collectionId: id,
    amount40: (amount40 / 100).toFixed(2),
    amount60: (amount60 / 100).toFixed(2),
    message:
      "Collection created. PayPal payout execution must be connected and verified before marking it completed."
  });
});

app.listen(PORT, () => {
  console.log(`Creator Donations running on http://localhost:${PORT}`);
});
