const crypto = require("crypto");

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  try {
    const [salt, key] = stored.split(":");
    if (!salt || !key) return false;

    const hash = crypto.scryptSync(password, salt, 64);
    const expected = Buffer.from(key, "hex");

    return expected.length === hash.length &&
      crypto.timingSafeEqual(expected, hash);
  } catch {
    return false;
  }
}

module.exports = { hashPassword, verifyPassword };
