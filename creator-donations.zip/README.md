# Creator Donations

A small Node.js/Express starter for a creator donation website.

## Features

- Donations without an account on your website
- PayPal order creation and server-side capture verification
- SQLite database
- Two-admin-ready password-hash system
- `/admin` dashboard
- 40/60 collection calculation
- Rate limiting and security headers
- HttpOnly admin session cookie

## Important

This repository is a starter, not a finished production payment platform.

The `Collect` endpoint intentionally creates a PENDING collection record and calculates the 40/60 split. It does NOT falsely claim that PayPal money was transferred.

Before production:

1. Create a PayPal Developer app.
2. Use Sandbox credentials for testing.
3. Configure the official PayPal JS SDK/Buttons.
4. Implement the supported PayPal Payouts/partner flow for your exact account arrangement.
5. Verify PayPal webhooks server-side.
6. Add idempotency and payout-state reconciliation.
7. Use HTTPS.
8. Put secrets in a proper secret manager/environment.
9. Add CSRF protection for state-changing admin requests.
10. Add 2FA for administrators.
11. Review PayPal's current terms and requirements for your business model.

## Install

```bash
npm install
cp .env.example .env
```

Edit `.env`.

Generate password hashes:

```bash
node -e "const a=require('./auth'); console.log(a.hashPassword('YOUR_PASSWORD'))"
```

Create the two admin records using your own secure provisioning script or SQLite tooling. Do not put plaintext passwords in the database.

Run:

```bash
npm start
```

Open:

- `http://localhost:3000/`
- `http://localhost:3000/admin`

## Node.js

Use a current supported Node.js LTS release.

## Production

Use HTTPS behind a reverse proxy such as Nginx, set `NODE_ENV=production`, use a persistent database/storage volume, and never commit `.env` or the SQLite database to source control.
